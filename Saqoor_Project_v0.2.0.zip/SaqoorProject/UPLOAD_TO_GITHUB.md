# رفع المشروع إلى GitHub من المتصفح

> تنبيه: GitHub لا يفك ZIP تلقائياً. لازم تفك الضغط أولاً، ثم ترفع محتويات مجلد `SaqoorProject`.

1. نزّل `Saqoor_Project_v0.2.0.zip` واحفظه في الفلاشة.
2. من Windows Explorer اضغط يمين على ZIP واختر `Extract All` وحدد الفلاشة.
3. افتح https://github.com/androemagindasupit-ship-it/abdullah-unity-game
4. اختر `Add file` ثم `Upload files`.
5. افتح مجلد `SaqoorProject` المستخرج. ارفع الملفات والمجلدات التي داخله، لا ترفع المجلد الخارجي كعنصر واحد إن كان ذلك سيضع الملفات في مسار فرعي.
6. يجب أن تظهر `index.html` و`README.md` و`.github` و`src` و`assets` و`UnityProject` مباشرة في جذر المستودع.
7. اكتب رسالة `Add Saqoor prototype v0.2.0` ثم `Commit changes`.
8. افتح `Settings > Pages` واختر `GitHub Actions` مصدراً للنشر عند الحاجة. ثم افتح `Actions` وتابع مهمة `Deploy Saqoor browser prototype`.

إذا رفعك المتصفح لا يسمح برفع مجلدات كاملة، ارفع كل الملفات والمجلدات على دفعات، وتأكد من عدم نسيان مجلد `.github/workflows`؛ فهو الذي يحتوي إعداد النشر.

هذا المستودع ظاهر للعامة حالياً حسب صفحة GitHub؛ لا ترفع فيه أسراراً أو كلمات مرور.
