from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
out=Path(__file__).parent/'assets'; out.mkdir(parents=True,exist_ok=True)
font='/usr/share/fonts/truetype/noto/NotoSansArabic-Black.ttf'
font_bold='/usr/share/fonts/truetype/noto/NotoSansArabic-Bold.ttf'
# Transparent standalone emblem for compact use.
im=Image.new('RGBA',(512,512),(0,0,0,0))
d=ImageDraw.Draw(im,'RGBA')
# softened gold halo
halo=Image.new('RGBA',im.size,(0,0,0,0)); hd=ImageDraw.Draw(halo)
hd.ellipse((96,58,416,380),fill=(214,173,86,30),outline=(233,201,127,100),width=2)
halo=halo.filter(ImageFilter.GaussianBlur(22)); im=Image.alpha_composite(im,halo); d=ImageDraw.Draw(im,'RGBA')
# Concentric emblem rings
d.ellipse((82,42,430,390),outline=(232,199,121,180),width=3)
d.ellipse((104,64,408,368),outline=(232,199,121,80),width=2)
d.arc((122,82,390,350),25,150,fill=(143,191,155,150),width=2)
d.arc((122,82,390,350),205,330,fill=(143,191,155,150),width=2)
# Abstract soaring falcon mark
gold=(235,205,135,255); light=(255,240,189,255); dark=(7,19,18,255)
# wings + tapered chest
d.polygon([(256,119),(294,168),(423,111),(350,195),(402,191),(303,245),(276,214),(269,296),(256,336),(243,296),(236,214),(209,245),(110,191),(162,195),(89,111),(218,168)],fill=gold)
d.polygon([(256,145),(279,186),(256,235),(233,186)],fill=dark)
d.polygon([(265,184),(307,167),(285,196)],fill=light)
d.line([(135,128),(213,174)],fill=(255,244,206,140),width=3); d.line([(377,128),(299,174)],fill=(255,244,206,140),width=3)
# little center jewel
d.polygon([(256,232),(270,250),(256,275),(242,250)],fill=(143,191,155,230))
# small word below emblem
f=ImageFont.truetype(font,48)
text='الصقور'; box=d.textbbox((0,0),text,font=f,direction='rtl',language='ar'); tw=box[2]-box[0]
d.text(((512-tw)/2,400),text,font=f,fill=light,stroke_width=0,direction='rtl',language='ar')
im.save(out/'saqoor-mark.png')
# Full splash logo with clearly rendered Arabic developer credit for Unity UI sprite.
im2=Image.new('RGBA',(1200,380),(0,0,0,0)); d2=ImageDraw.Draw(im2,'RGBA')
# abstract gold falcon on left
cx,cy=150,165
d2.ellipse((35,45,265,275),outline=(232,199,121,180),width=3)
d2.ellipse((54,64,246,256),outline=(232,199,121,78),width=2)
d2.polygon([(cx,75),(cx+30,112),(cx+104,84),(cx+58,133),(cx+88,131),(cx+30,160),(cx+17,141),(cx+12,201),(cx,228),(cx-12,201),(cx-17,141),(cx-30,160),(cx-88,131),(cx-58,133),(cx-104,84),(cx-30,112)],fill=gold)
d2.polygon([(cx,90),(cx+18,124),(cx,152),(cx-18,124)],fill=dark)
main_font=ImageFont.truetype(font,78)
sub_font=ImageFont.truetype(font_bold,39)
small_font=ImageFont.truetype('/usr/share/fonts/opentype/inter/Inter-Regular.otf',23)
main='ميدان الصقور'; sub='تطوير عبدالله لازم'; small='SAQOOR  ·  SURVIVAL PROJECT'
# right-aligned title to suit RTL
for text,y,ft,color in [(main,71,main_font,(255,239,190,255)),(sub,177,sub_font,(232,199,121,255)),(small,247,small_font,(143,191,155,255))]:
    b=d2.textbbox((0,0),text,font=ft,direction='rtl',language='ar' if any('\u0600'<=ch<='\u06ff' for ch in text) else 'en')
    width=b[2]-b[0]
    d2.text((1150-width,y),text,font=ft,fill=color,direction='rtl' if any('\u0600'<=ch<='\u06ff' for ch in text) else 'ltr',language='ar' if any('\u0600'<=ch<='\u06ff' for ch in text) else 'en')
# thin gold underline
d2.line((340,309,1120,309),fill=(232,199,121,130),width=2)
im2.save(out/'saqoor-splash.png')
print('Generated', out/'saqoor-mark.png', out/'saqoor-splash.png')
