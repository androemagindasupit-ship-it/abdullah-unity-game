"""Create original Saqoor 3D starter assets in Blender.

Run inside Blender with:
  blender --background --python create_saqoor_assets.py
or open Blender > Scripting > Open > Run Script.

Outputs are written to BlenderTools/generated_assets:
  - saqoor_falcon_emblem.glb
  - saqoor_operator.glb
  - saqoor_supply_crate.glb
  - saqoor_assets.blend
  - saqoor_emblem_preview.png (render if the active engine supports it)

This is stylized, original low-poly starter art, not a finished AAA character.
"""
import bpy
import math
import os
from mathutils import Vector

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else bpy.path.abspath("//")
OUT_DIR = os.path.join(SCRIPT_DIR, "generated_assets")
os.makedirs(OUT_DIR, exist_ok=True)

# Clean scene
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.cameras, bpy.data.lights):
    for block in list(datablocks):
        if block.users == 0:
            datablocks.remove(block)

scene = bpy.context.scene
scene.render.engine = "CYCLES" if "CYCLES" in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items.keys() else "BLENDER_EEVEE_NEXT"
scene.render.resolution_x = 1200
scene.render.resolution_y = 900
scene.render.resolution_percentage = 100
scene.render.film_transparent = True
scene.world.color = (0.008, 0.02, 0.018)
scene.view_settings.view_transform = "AgX"

# Organized collections
root = scene.collection

def collection(name):
    c = bpy.data.collections.new(name)
    root.children.link(c)
    return c

emblem_col = collection("01_Saqoor_Falcon_Emblem")
operator_col = collection("02_Saqoor_Operator_Starter")
crate_col = collection("03_Supply_Crate_Prop")
scene_col = collection("04_Studio_Camera_Lights")

def move_to_collection(obj, target):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    target.objects.link(obj)
    return obj

def material(name, color, metallic=0.0, roughness=0.45):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1.0)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*color, 1.0)
    bsdf.inputs["Metallic"].default_value = metallic
    bsdf.inputs["Roughness"].default_value = roughness
    return m

GOLD = material("Saqoor · Brushed Gold", (0.78, 0.54, 0.22), 0.78, 0.27)
PALE_GOLD = material("Saqoor · Highlight Gold", (0.98, 0.82, 0.48), 0.65, 0.24)
DARK = material("Saqoor · Deep Teal Enamel", (0.018, 0.075, 0.073), 0.42, 0.3)
JADE = material("Saqoor · Jade Accent", (0.14, 0.42, 0.31), 0.48, 0.28)
ARMOR = material("Operator · Field Green Armor", (0.12, 0.22, 0.20), 0.18, 0.48)
ARMOR_LIGHT = material("Operator · Olive Panels", (0.25, 0.31, 0.22), 0.22, 0.5)
RUBBER = material("Operator · Charcoal Rubber", (0.035, 0.055, 0.052), 0.08, 0.62)
FABRIC = material("Operator · Dark Fabric", (0.075, 0.105, 0.094), 0.0, 0.85)
SKIN = material("Operator · Warm Skin Tone", (0.34, 0.22, 0.15), 0.0, 0.65)
CRATE_GREEN = material("Crate · Deep Olive", (0.19, 0.25, 0.18), 0.16, 0.55)
CRATE_GOLD = material("Crate · Marking Gold", (0.93, 0.67, 0.24), 0.42, 0.32)

# --- shared mesh utilities ---
def cube(name, location, dimensions, mat, target, bevel=0.04):
    bpy.ops.mesh.primitive_cube_add(size=1.0, location=location)
    obj = move_to_collection(bpy.context.object, target)
    obj.name = name
    obj.dimensions = dimensions
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.data.materials.append(mat)
    if bevel > 0:
        mod = obj.modifiers.new("Soft manufactured edges", "BEVEL")
        mod.width = bevel
        mod.segments = 2
        obj.modifiers.new("Weighted face normals", "WEIGHTED_NORMAL")
    return obj

def uv_sphere(name, location, scale, mat, target, segments=16, rings=10):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=rings, radius=1.0, location=location)
    obj = move_to_collection(bpy.context.object, target)
    obj.name = name
    obj.scale = scale
    obj.data.materials.append(mat)
    for p in obj.data.polygons:
        p.use_smooth = True
    return obj

def cylinder(name, location, radius, depth, mat, target, vertices=16, bevel=0.02):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=location)
    obj = move_to_collection(bpy.context.object, target)
    obj.name = name
    obj.data.materials.append(mat)
    if bevel:
        mod = obj.modifiers.new("Edge chamfer", "BEVEL")
        mod.width = bevel
        mod.segments = 2
        obj.modifiers.new("Weighted face normals", "WEIGHTED_NORMAL")
    return obj

def extruded_polygon(name, points, depth, mat, target, bevel=0.025):
    n = len(points)
    verts = [(x, y, -depth / 2) for x, y in points] + [(x, y, depth / 2) for x, y in points]
    faces = [tuple(range(n - 1, -1, -1)), tuple(range(n, 2 * n))]
    for i in range(n):
        j = (i + 1) % n
        faces.append((i, j, n + j, n + i))
    mesh = bpy.data.meshes.new(name + " Mesh")
    mesh.from_pydata(verts, [], faces)
    mesh.materials.append(mat)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    target.objects.link(obj)
    if bevel:
        mod = obj.modifiers.new("Machined bevel", "BEVEL")
        mod.width = bevel
        mod.segments = 3
        obj.modifiers.new("Weighted corner normals", "WEIGHTED_NORMAL")
    return obj

# --- Falcon badge ---
bpy.ops.mesh.primitive_cylinder_add(vertices=96, radius=2.15, depth=0.22, location=(0, 0, -0.16))
disk = move_to_collection(bpy.context.object, emblem_col)
disk.name = "Falcon medallion · teal enamel"
disk.data.materials.append(DARK)
mod = disk.modifiers.new("Soft rim", "BEVEL"); mod.width = 0.055; mod.segments = 3
disk.modifiers.new("Weighted normals", "WEIGHTED_NORMAL")
for major, minor, z, mat in [(2.16, 0.035, -0.015, PALE_GOLD), (1.98, 0.018, 0.005, GOLD), (1.80, 0.012, 0.014, JADE)]:
    bpy.ops.mesh.primitive_torus_add(major_radius=major, minor_radius=minor, major_segments=96, minor_segments=10, location=(0, 0, z))
    obj = move_to_collection(bpy.context.object, emblem_col); obj.name = "Engraved circular ring"; obj.data.materials.append(mat)
left_wing = [(-0.10, 0.88), (-0.62, 1.28), (-1.83, 1.73), (-1.38, 1.12), (-1.77, 1.10), (-0.80, 0.53), (-0.48, 0.66), (-0.28, -0.1)]
right_wing = [(-x, y) for x, y in reversed(left_wing)]
extruded_polygon("Left swept wing", left_wing, 0.12, GOLD, emblem_col)
extruded_polygon("Right swept wing", right_wing, 0.12, GOLD, emblem_col)
extruded_polygon("Falcon chest", [(0, 1.0), (0.32, .45), (.18, -.18), (0, -.75), (-.18, -.18), (-.32, .45)], .16, PALE_GOLD, emblem_col)
extruded_polygon("Falcon crown", [(0, .65), (.43, .56), (.22, .42), (0, .48), (-.22, .42), (-.43, .56)], .17, GOLD, emblem_col)
extruded_polygon("Falcon jade beak", [(.05, .58), (.34, .65), (.20, .45)], .18, JADE, emblem_col, .012)
for degrees in range(0, 360, 30):
    a = math.radians(degrees)
    rivet = uv_sphere("Precision gold rivet", (2.0 * math.cos(a), 2.0 * math.sin(a), 0.015), (.045, .045, .025), PALE_GOLD, emblem_col, 12, 8)

# --- Original stylized low-poly field operator ---
# Build around origin; facing local -Y in Blender, converted by glTF exporter.
# Root empty lets Unity animate/rotate the full character.
operator_root = bpy.data.objects.new("SAQOOR_OPERATOR_ROOT", None)
operator_col.objects.link(operator_root)
operator_root.empty_display_type = "PLAIN_AXES"
operator_root.empty_display_size = 0.4

def parent_operator(obj):
    obj.parent = operator_root
    return obj

# Boots and armored legs
for side, label in [(-1, "L"), (1, "R")]:
    x = side * 0.22
    parent_operator(cube("Boot " + label, (x, -0.06, 0.12), (0.30, 0.43, 0.23), RUBBER, operator_col, .055))
    parent_operator(cube("Shin guard " + label, (x, 0, 0.30), (0.30, 0.33, 0.47), ARMOR_LIGHT, operator_col, .055))
    parent_operator(cube("Knee pad " + label, (x, -0.01, 0.53), (0.33, 0.35, 0.18), RUBBER, operator_col, .045))
    parent_operator(cube("Thigh armor " + label, (x, 0.02, 0.79), (0.34, 0.37, 0.42), ARMOR, operator_col, .06))
# Chest, vest, plates, collar and shoulder armor
parent_operator(cube("Lower torso", (0, 0.02, 1.12), (.70, .40, .45), ARMOR, operator_col, .09))
parent_operator(cube("Tactical vest", (0, -0.045, 1.33), (.77, .27, .55), FABRIC, operator_col, .08))
parent_operator(cube("Left chest plate", (-.19, -.19, 1.41), (.29, .10, .32), ARMOR_LIGHT, operator_col, .035))
parent_operator(cube("Right chest plate", (.19, -.19, 1.41), (.29, .10, .32), ARMOR_LIGHT, operator_col, .035))
parent_operator(cube("Falcon chest insignia", (0, -.252, 1.35), (.14, .026, .15), CRATE_GOLD, operator_col, .012))
parent_operator(cube("Utility belt", (0, -.01, 1.01), (.76, .39, .11), RUBBER, operator_col, .025))
parent_operator(cube("Backpack", (0, .25, 1.34), (.48, .29, .63), ARMOR_LIGHT, operator_col, .08))
parent_operator(cube("Backpack top flap", (0, .25, 1.63), (.43, .30, .12), ARMOR, operator_col, .025))
parent_operator(cube("Neck guard", (0, 0, 1.63), (.26, .26, .16), RUBBER, operator_col, .03))
# Head and helmet
parent_operator(uv_sphere("Head", (0, 0.01, 1.83), (.19, .18, .25), SKIN, operator_col, 16, 12))
parent_operator(uv_sphere("Ballistic helmet", (0, 0.01, 1.99), (.255, .23, .19), ARMOR_LIGHT, operator_col, 16, 10))
parent_operator(cube("Helmet front rim", (0, -.205, 1.96), (.36, .055, .055), RUBBER, operator_col, .025))
parent_operator(cube("Helmet gold stripe", (0, -.04, 2.11), (.07, .25, .055), CRATE_GOLD, operator_col, .01))
# Arms / shoulder / gloves
for side, label in [(-1, "L"), (1, "R")]:
    parent_operator(uv_sphere("Shoulder " + label, (side * .48, .02, 1.49), (.22, .23, .22), ARMOR_LIGHT, operator_col, 12, 8))
    parent_operator(cube("Upper arm " + label, (side * .49, -.015, 1.27), (.22, .23, .40), ARMOR, operator_col, .055))
    parent_operator(cube("Forearm plate " + label, (side * .50, -.10, 1.02), (.21, .24, .25), ARMOR_LIGHT, operator_col, .045))
    parent_operator(uv_sphere("Glove " + label, (side * .50, -.11, .86), (.13, .14, .12), RUBBER, operator_col, 12, 8))
# A compact, stylized training rifle; no logos or real-world weapon detail.
parent_operator(cube("Training rifle body", (.30, -.44, 1.11), (.15, .61, .16), RUBBER, operator_col, .025))
parent_operator(cube("Training rifle handguard", (.30, -.67, 1.12), (.18, .30, .18), ARMOR_LIGHT, operator_col, .025))
parent_operator(cube("Training rifle barrel", (.30, -.91, 1.12), (.055, .26, .055), DARK, operator_col, .012))
parent_operator(cube("Training rifle stock", (.30, -.17, 1.12), (.14, .22, .17), FABRIC, operator_col, .025))
parent_operator(cube("Training rifle magazine", (.30, -.48, .98), (.09, .13, .22), DARK, operator_col, .018))
# Small fabric gear pouches and shoulder comms
parent_operator(cube("Left utility pouch", (-.31, -.18, 1.04), (.15, .12, .19), ARMOR_LIGHT, operator_col, .025))
parent_operator(cube("Right utility pouch", (.31, -.18, 1.04), (.15, .12, .19), ARMOR_LIGHT, operator_col, .025))
parent_operator(cube("Radio antenna", (-.20, .22, 1.71), (.025, .025, .23), RUBBER, operator_col, .006))

# --- Supply crate prop ---
crate_root = bpy.data.objects.new("SAQOOR_SUPPLY_CRATE_ROOT", None)
crate_col.objects.link(crate_root)
crate_root.empty_display_type = "CUBE"
crate_root.empty_display_size = 0.6

def parent_crate(obj):
    obj.parent = crate_root
    return obj

parent_crate(cube("Crate base", (0, 0, 0.55), (1.55, 1.15, 1.1), CRATE_GREEN, crate_col, .08))
parent_crate(cube("Armored lid", (0, 0, 1.12), (1.62, 1.22, .16), RUBBER, crate_col, .035))
for x in [-.62, .62]:
    parent_crate(cube("Gold corner rail", (x, -.59, .58), (.10, .055, .95), CRATE_GOLD, crate_col, .012))
    parent_crate(cube("Gold corner rail rear", (x, .59, .58), (.10, .055, .95), CRATE_GOLD, crate_col, .012))
for y in [-.43, .43]:
    parent_crate(cube("Reinforced lid strap", (0, y, 1.22), (1.4, .09, .05), CRATE_GOLD, crate_col, .015))
parent_crate(cube("Falcon marking plate", (0, -.584, .61), (.55, .035, .40), DARK, crate_col, .02))
mark = extruded_polygon("Crate falcon mark", [(-.17, .1), (-.38, .22), (-.22, .0), (-.1, -.04), (0, -.23), (.1, -.04), (.22, 0), (.38, .22), (.17, .1), (.07, .11), (0, .03), (-.07, .11)], .035, CRATE_GOLD, crate_col, .01)
mark.location = (0, -.61, .61)
mark.rotation_euler.x = math.radians(90)
parent_crate(mark)

# Studio setup, aimed at emblem for easy preview

def area_light(name, location, energy, color, size):
    data = bpy.data.lights.new(name, "AREA")
    data.energy = energy; data.color = color; data.shape = "DISK"; data.size = size
    obj = bpy.data.objects.new(name, data); scene_col.objects.link(obj); obj.location = location
    obj.rotation_euler = (Vector((0, 0, 0)) - obj.location).to_track_quat("-Z", "Y").to_euler()
    return obj

area_light("Warm key", (1.0, 3.6, 5.2), 820, (1.0, .78, .45), 4.0)
area_light("Cool fill", (-4.0, .5, 3.0), 580, (.40, .77, .75), 3.0)
area_light("Rim light", (2.0, -3.0, 2.5), 700, (1.0, .87, .63), 2.5)
cam_data = bpy.data.cameras.new("Falcon emblem preview camera")
cam = bpy.data.objects.new("Falcon emblem preview camera", cam_data); scene_col.objects.link(cam)
cam.location = (0, 0, 8.5); cam.rotation_euler = (0, 0, 0); cam_data.type = "ORTHO"; cam_data.ortho_scale = 5.8; scene.camera = cam
scene.render.image_settings.file_format = "PNG"; scene.render.image_settings.color_mode = "RGBA"
scene.render.filepath = os.path.join(OUT_DIR, "saqoor_emblem_preview.png")

# Export each asset collection separately for simple import into Unity.
def export_collection(target, filename):
    bpy.ops.object.select_all(action="DESELECT")
    for obj in target.objects:
        obj.select_set(True)
    bpy.context.view_layer.objects.active = next(iter(target.objects), None)
    if bpy.context.view_layer.objects.active:
        bpy.ops.export_scene.gltf(filepath=os.path.join(OUT_DIR, filename), export_format="GLB", use_selection=True, export_apply=True)

export_collection(emblem_col, "saqoor_falcon_emblem.glb")
export_collection(operator_col, "saqoor_operator.glb")
export_collection(crate_col, "saqoor_supply_crate.glb")
# Save full editable scene, with all collections and source objects.
bpy.ops.object.select_all(action="DESELECT")
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT_DIR, "saqoor_assets.blend"))
print("Saqoor asset generation finished:", OUT_DIR)
