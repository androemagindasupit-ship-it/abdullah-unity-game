"""Generate a stylized metallic Saqoor falcon emblem in Blender.

Run with Blender's Scripting workspace. The generated model is intentionally low-poly
and can be exported as glTF/GLB for later use in Unity. This script has not been
executed here because Blender is not installed in the current build environment.
"""
import bpy
import math
from mathutils import Vector

# Clear the scene.
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.cameras, bpy.data.lights):
    for block in list(datablocks):
        if block.users == 0:
            datablocks.remove(block)

scene = bpy.context.scene
scene.render.engine = 'CYCLES' if 'CYCLES' in bpy.types.RenderSettings.bl_rna.properties['engine'].enum_items.keys() else 'BLENDER_EEVEE_NEXT'
scene.render.resolution_x = 1200
scene.render.resolution_y = 900
scene.render.resolution_percentage = 100
scene.render.film_transparent = True
scene.world.color = (0.012, 0.025, 0.024)


def make_material(name, color, metallic=0.0, roughness=0.45):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1.0)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get('Principled BSDF')
    bsdf.inputs['Base Color'].default_value = (*color, 1.0)
    bsdf.inputs['Metallic'].default_value = metallic
    bsdf.inputs['Roughness'].default_value = roughness
    return m

GOLD = make_material('Falcon Gold', (0.78, 0.54, 0.22), 0.78, 0.27)
PALE_GOLD = make_material('Etched Pale Gold', (0.98, 0.82, 0.48), 0.65, 0.24)
DARK = make_material('Deep Teal Enamel', (0.025, 0.11, 0.105), 0.44, 0.32)
GREEN = make_material('Jade Accent', (0.16, 0.48, 0.36), 0.5, 0.28)


def extruded_polygon(name, points, depth, material, bevel=0.035):
    # Polygon lies in XY; thickness extends along local Z.
    n = len(points)
    verts = [(x, y, -depth / 2) for x, y in points] + [(x, y, depth / 2) for x, y in points]
    faces = [tuple(range(n - 1, -1, -1)), tuple(range(n, 2 * n))]
    for i in range(n):
        j = (i + 1) % n
        faces.append((i, j, n + j, n + i))
    mesh = bpy.data.meshes.new(name + ' Mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.materials.append(material)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    if bevel:
        mod = obj.modifiers.new('Machined bevel', 'BEVEL')
        mod.width = bevel
        mod.segments = 3
        obj.modifiers.new('Weighted corner normals', 'WEIGHTED_NORMAL')
    return obj

# Dark enamel disk and precision rim.
bpy.ops.mesh.primitive_cylinder_add(vertices=96, radius=2.25, depth=0.22, location=(0, 0, -0.16))
disk = bpy.context.object
disk.name = 'Saqoor Enamel Medallion'
disk.data.materials.append(DARK)
bevel = disk.modifiers.new('Soft rim', 'BEVEL'); bevel.width = 0.06; bevel.segments = 3
disk.modifiers.new('Weighted normals', 'WEIGHTED_NORMAL')
for major, minor, z, material in [(2.23, 0.035, 0.0, PALE_GOLD), (2.03, 0.014, 0.01, GOLD), (1.88, 0.012, 0.012, GREEN)]:
    bpy.ops.mesh.primitive_torus_add(major_radius=major, minor_radius=minor, major_segments=96, minor_segments=10, location=(0, 0, z))
    obj = bpy.context.object; obj.name = 'Etched ring'; obj.data.materials.append(material)

# Symmetric sweeping wing geometry, a stylized original bird symbol.
left_wing = [(-0.1, 0.88), (-0.62, 1.28), (-1.83, 1.73), (-1.38, 1.12), (-1.77, 1.10), (-0.80, 0.53), (-0.48, 0.66), (-0.28, -0.1)]
right_wing = [(-x, y) for x, y in reversed(left_wing)]
extruded_polygon('Left aerodynamic wing', left_wing, 0.12, GOLD, 0.025)
extruded_polygon('Right aerodynamic wing', right_wing, 0.12, GOLD, 0.025)
body = [(0, 1.0), (0.32, 0.45), (0.18, -0.18), (0, -0.75), (-0.18, -0.18), (-0.32, 0.45)]
extruded_polygon('Falcon chest', body, 0.16, PALE_GOLD, 0.035)
head = [(0, 0.65), (0.43, 0.56), (0.22, 0.42), (0, 0.48), (-0.22, 0.42), (-0.43, 0.56)]
extruded_polygon('Falcon crown', head, 0.17, GOLD, 0.025)
beak = [(0.05, 0.58), (0.34, 0.65), (0.20, 0.45)]
extruded_polygon('Falcon beak', beak, 0.18, GREEN, 0.012)

# Small rivets add manufactured detail.
for a in range(0, 360, 30):
    ang = math.radians(a)
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12, ring_count=6, radius=0.045, location=(2.08 * math.cos(ang), 2.08 * math.sin(ang), 0.0))
    rivet = bpy.context.object; rivet.name = 'Gold rivet'; rivet.scale.z = 0.45; rivet.data.materials.append(PALE_GOLD)

# Studio lighting and a straight-on camera for a polished render.
def area_light(name, location, energy, color, size):
    data = bpy.data.lights.new(name, 'AREA'); data.energy = energy; data.color = color; data.shape = 'DISK'; data.size = size
    obj = bpy.data.objects.new(name, data); bpy.context.collection.objects.link(obj); obj.location = location
    obj.rotation_euler = (Vector((0, 0, 0)) - obj.location).to_track_quat('-Z', 'Y').to_euler()
    return obj

area_light('Warm key', (1.0, 3.6, 5.2), 820, (1.0, 0.78, 0.45), 4.0)
area_light('Cool fill', (-4.0, 0.5, 3.0), 580, (0.40, 0.77, 0.75), 3.0)
area_light('Rim light', (2.0, -3.0, 2.5), 700, (1.0, 0.87, 0.63), 2.5)
cam_data = bpy.data.cameras.new('Saqoor Emblem Camera')
cam = bpy.data.objects.new('Saqoor Emblem Camera', cam_data); bpy.context.collection.objects.link(cam)
cam.location = (0, 0, 8.5); cam.rotation_euler = (0, 0, 0); cam_data.type = 'ORTHO'; cam_data.ortho_scale = 5.8; scene.camera = cam
scene.render.image_settings.file_format = 'PNG'; scene.render.image_settings.color_mode = 'RGBA'; scene.render.filepath = '//saqoor_emblem_render.png'
scene.view_settings.view_transform = 'AgX'

# Select the central emblem before leaving the scene ready for editing/export.
bpy.ops.object.select_all(action='DESELECT')
for obj in bpy.context.scene.objects:
    if obj.name in {'Saqoor Enamel Medallion', 'Left aerodynamic wing', 'Right aerodynamic wing', 'Falcon chest', 'Falcon crown', 'Falcon beak'}:
        obj.select_set(True)
bpy.context.view_layer.objects.active = bpy.data.objects.get('Saqoor Enamel Medallion')
print('Saqoor Falcon Emblem scene is ready. Save as saqoor_emblem.blend, then export selected emblem as glTF/GLB for Unity.')
