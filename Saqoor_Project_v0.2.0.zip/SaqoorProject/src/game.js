import * as THREE from 'three';

const $ = id => document.getElementById(id);
const UI = {
  intro: $('intro'), menu: $('menu'), hud: $('hud'), settings: $('settings'), about: $('about'),
  gameOver: $('gameOver'), health: $('healthNumber'), healthFill: $('healthFill'), alive: $('alive'),
  kills: $('kills'), ammo: $('ammo'), zoneTime: $('zoneTime'), zoneStatus: $('zoneStatus'),
  runState: $('runState'), hint: $('hint'), toast: $('toast'), error: $('errorPanel')
};
const canvas = $('world');
let gameState = 'menu';
let gameTime = 0, yaw = 0, pitch = 0.16, sensitivity = 1, quality = 'medium';
let soundOn = false, audioContext = null, fireHeld = false, ammo = 30, reloading = false;
let reloadAt = 0, kills = 0, health = 100, toastUntil = 0, fireCooldown = 0, jumpVelocity = 0;
let grounded = true, jumpQueued = false, touchDragging = false, lastTouchX = 0, lastTouchY = 0, joystickPointer = null;
let toastMessage = '', safeRadius = 145, zoneUpdateTime = 0, minimapUpdateTime = 0;
const keys = Object.create(null);
const touchMove = { x: 0, y: 0 };
const disposableLines = [];
const clock = new THREE.Clock();

let renderer, scene, camera;
try {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.4));
  renderer.setSize(innerWidth, innerHeight);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x8caeac);
  scene.fog = new THREE.FogExp2(0x8caeac, 0.0033);
  camera = new THREE.PerspectiveCamera(60, innerWidth / innerHeight, 0.1, 700);
} catch (error) {
  console.error(error);
  UI.error.classList.remove('hidden');
  throw error;
}

scene.add(new THREE.HemisphereLight(0xd8e8e2, 0x374432, 2.05));
const sun = new THREE.DirectionalLight(0xffe3b2, 3.05);
sun.position.set(-90, 125, 45);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -145; sun.shadow.camera.right = 145;
sun.shadow.camera.top = 145; sun.shadow.camera.bottom = -145;
sun.shadow.bias = -0.0003;
scene.add(sun);
const fillLight = new THREE.DirectionalLight(0x94b1b0, 0.62);
fillLight.position.set(70, 38, -80); scene.add(fillLight);

const materialCache = new Map();
function material(color, roughness = 0.84, metalness = 0) {
  const key = `${color}-${roughness}-${metalness}`;
  if (!materialCache.has(key)) materialCache.set(key, new THREE.MeshStandardMaterial({ color, roughness, metalness }));
  return materialCache.get(key);
}
function addBox(parent, x, y, z, w, h, d, mat, rotation = 0, castShadow = true) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  mesh.position.set(x, y, z); mesh.rotation.y = rotation;
  mesh.castShadow = castShadow; mesh.receiveShadow = true; parent.add(mesh); return mesh;
}
function seeded(seed) { return () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; }; }
const random = seeded(1884);
function terrainHeight(x, z) {
  const radius = Math.hypot(x, z);
  let h = Math.sin(x * 0.043) * 1.15 + Math.cos(z * 0.051) * 1.25 + Math.sin((x + z) * 0.028) * 1.1 + Math.cos((x - z) * 0.019) * 0.8;
  h += Math.max(0, Math.abs(x + 24) * 0.018 + Math.abs(z - 62) * 0.01 - 1) * 1.5;
  h -= Math.max(0, radius - 133) * 0.5;
  return h;
}

// Procedural terrain: no large asset downloads required.
const terrainGeometry = new THREE.PlaneGeometry(360, 360, 80, 80);
const attr = terrainGeometry.attributes.position;
const vertexColors = [];
for (let i = 0; i < attr.count; i++) {
  const x = attr.getX(i), z = -attr.getY(i), y = terrainHeight(x, z);
  attr.setZ(i, y);
  let c = y > 3 ? new THREE.Color(0x85846a) : y < -0.4 ? new THREE.Color(0x64784e) : new THREE.Color(0x718a59);
  c.multiplyScalar(0.92 + random() * 0.14);
  vertexColors.push(c.r, c.g, c.b);
}
terrainGeometry.setAttribute('color', new THREE.Float32BufferAttribute(vertexColors, 3));
terrainGeometry.rotateX(-Math.PI / 2); terrainGeometry.computeVertexNormals();
const terrain = new THREE.Mesh(terrainGeometry, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1 }));
terrain.receiveShadow = true; scene.add(terrain);
const water = new THREE.Mesh(new THREE.PlaneGeometry(820, 820), material(0x39737a, 0.45, 0.08));
water.rotation.x = -Math.PI / 2; water.position.y = -7.2; water.receiveShadow = true; scene.add(water);
const sunDisk = new THREE.Mesh(new THREE.SphereGeometry(6.5, 18, 12), new THREE.MeshBasicMaterial({ color: 0xffe7b0 }));
sunDisk.position.set(-140, 80, -210); scene.add(sunDisk);

function buildRoad(x, z, length, angle) {
  addBox(scene, x, 0.05, z, 5.3, 0.12, length, material(0x454b42), angle, false);
  addBox(scene, x, 0.12, z, 0.12, 0.02, length * 0.92, material(0xcab57c), angle, false);
}
buildRoad(-45, 5, 175, -0.42); buildRoad(42, -24, 132, 0.58); buildRoad(10, 53, 91, -0.92);
function building(x, z, w, d, h, angle = 0, industrial = false) {
  const root = new THREE.Group(); root.position.set(x, terrainHeight(x, z) + 0.08, z); root.rotation.y = angle; scene.add(root);
  const wall = material(industrial ? 0x77796a : 0x948a70);
  addBox(root, 0, h * 0.5, 0, w, h, d, wall);
  addBox(root, 0, h + 0.2, 0, w + 0.5, 0.34, d + 0.5, material(0x343a34));
  addBox(root, 0, h + 0.4, 0, w * 0.55, 0.07, d * 0.44, material(0x9e7045));
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) addBox(root, sx * w * 0.27, h * 0.53, sz * d * 0.5, 0.58, 1.5, 0.12, material(0x293b3a, 0.5, 0.06));
  addBox(root, w * 0.2, h * 0.45, d * 0.5 + 0.08, 0.8, h * 0.72, 0.16, material(0x4b5048, 0.6));
}
building(-65, -8, 17, 13, 7, 0.2); building(-24, -63, 12, 15, 5.8, -0.25, true);
building(38, 19, 19, 12, 8, 0.48); building(72, -45, 13, 13, 5.7, -0.55, true);
building(-89, 48, 12, 10, 5.5, 0.1); building(16, 78, 16, 11, 6.2, 0.8);
building(92, 33, 10, 14, 5.3, -0.3); building(-13, 5, 8, 9, 4.1, 0.1, true);
function tree(x, z, scale = 1) {
  const root = new THREE.Group(); root.position.set(x, terrainHeight(x, z), z); root.scale.setScalar(scale); scene.add(root);
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.29, 2.05, 7), material(0x5d4a33));
  trunk.position.y = 1.02; trunk.castShadow = true; root.add(trunk);
  const colors = [0x304831, 0x405b3b, 0x536e43];
  for (let i = 0; i < 3; i++) {
    const cone = new THREE.Mesh(new THREE.ConeGeometry(1.25 - i * 0.17, 2.2, 7), material(colors[i]));
    cone.position.y = 2.0 + i * 0.77; cone.castShadow = true; cone.receiveShadow = true; root.add(cone);
  }
}
let trees = 0;
while (trees < 72) {
  const x = (random() - 0.5) * 280, z = (random() - 0.5) * 280;
  if (Math.hypot(x, z) > 142 || Math.hypot(x, z - 25) < 20 || (Math.abs(x + 45) < 5 && Math.abs(z) < 70)) continue;
  tree(x, z, 0.74 + random() * 0.6); trees++;
}
for (let i = 0; i < 46; i++) {
  const x = (random() - 0.5) * 270, z = (random() - 0.5) * 270, s = 0.5 + random() * 1.15;
  if (Math.hypot(x, z) < 20 || Math.hypot(x, z) > 143) continue;
  const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(s, 0), material(0x73796a));
  rock.position.set(x, terrainHeight(x, z) + s * 0.5, z); rock.rotation.set(random(), random() * Math.PI, random());
  rock.scale.set(1, 0.72, 0.9); rock.castShadow = true; rock.receiveShadow = true; scene.add(rock);
}
function crate(x, z, color = 0x8b633b) {
  const y = terrainHeight(x, z);
  addBox(scene, x, y + 0.7, z, 2, 1.4, 1.7, material(color));
  addBox(scene, x, y + 0.7, z, 2.04, 0.12, 1.75, material(0x252e28), 0.28);
  for (const dx of [-0.72, 0.72]) addBox(scene, x + dx, y + 0.7, z, 0.08, 1.42, 1.78, material(0xceb06b));
}
crate(-19, 28, 0x686e58); crate(50, -11, 0x8b5135); crate(-79, -20, 0x6b705d); crate(25, 64, 0x875c37);

function soldier(color, accent = 0xe3c16f) {
  const group = new THREE.Group(), armor = material(color, 0.62), trim = material(accent, 0.54, 0.08), dark = material(0x202a28, 0.5, 0.12), skin = material(0x9b7b5e);
  const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.34, 0.68, 4, 8), armor); body.position.y = 1.18; body.castShadow = true; group.add(body);
  const vest = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.56, 0.32), dark); vest.position.set(0, 1.18, -0.03); vest.castShadow = true; group.add(vest);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.23, 12, 10), skin); head.position.y = 1.88; head.castShadow = true; group.add(head);
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.26, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.58), trim); helmet.position.y = 1.97; helmet.castShadow = true; group.add(helmet);
  const limbs = [];
  for (const side of [-1, 1]) {
    const leg = new THREE.Mesh(new THREE.CapsuleGeometry(0.12, 0.55, 3, 6), dark); leg.position.set(side * 0.16, 0.43, 0); leg.castShadow = true; group.add(leg);
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.095, 0.5, 3, 6), armor); arm.position.set(side * 0.43, 1.22, -0.03); arm.rotation.z = side * 0.17; arm.castShadow = true; group.add(arm); limbs.push(leg, arm);
  }
  const gun = addBox(group, 0.42, 1.2, -0.46, 0.14, 0.14, 0.78, dark, -0.1);
  return { group, meshes: group.children, limbs, gun };
}
const playerVisual = soldier(0x304b4a, 0xe6c573);
const player = { ...playerVisual, x: 0, z: 27, alive: true, baseY: terrainHeight(0, 27) };
player.group.position.set(player.x, player.baseY, player.z); scene.add(player.group);
const bots = [];
function makeBots() {
  for (const b of bots) scene.remove(b.group);
  bots.length = 0;
  for (let i = 0; i < 8; i++) {
    const angle = i / 8 * Math.PI * 2 + 0.3, radius = 43 + (i % 3) * 16;
    const x = Math.cos(angle) * radius, z = Math.sin(angle) * radius + 7;
    const visual = soldier([0x76473d, 0x4e5f49, 0x514b61, 0x7f6842][i % 4], [0xb6a06d, 0xd17a5e, 0x819a8d][i % 3]);
    const bot = { ...visual, x, z, hp: 100, alive: true, cool: 1 + random() * 1.8, seed: random() * 9, homeX: x, homeZ: z };
    bot.group.position.set(x, terrainHeight(x, z), z);
    bot.group.traverse(obj => { if (obj.isMesh) obj.userData.bot = bot; });
    scene.add(bot.group); bots.push(bot);
  }
}
makeBots();

const zonePoints = [];
for (let i = 0; i <= 160; i++) { const angle = i / 160 * Math.PI * 2; zonePoints.push(new THREE.Vector3(Math.cos(angle) * safeRadius, 0.24, Math.sin(angle) * safeRadius)); }
const zoneGeometry = new THREE.BufferGeometry().setFromPoints(zonePoints);
const zoneLine = new THREE.Line(zoneGeometry, new THREE.LineBasicMaterial({ color: 0x8fe0d7, transparent: true, opacity: 0.9 })); scene.add(zoneLine);
function setZoneRadius(radius) {
  if (Math.abs(radius - safeRadius) < 1.2) return;
  safeRadius = radius;
  const pts = [];
  for (let i = 0; i <= 160; i++) { const a = i / 160 * Math.PI * 2; pts.push(new THREE.Vector3(Math.cos(a) * radius, 0.24, Math.sin(a) * radius)); }
  zoneLine.geometry.dispose(); zoneLine.geometry = new THREE.BufferGeometry().setFromPoints(pts);
}
function addTracer(from, to, color = 0xf7d98c) {
  const geom = new THREE.BufferGeometry().setFromPoints([from.clone(), to.clone()]);
  const line = new THREE.Line(geom, new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.95 }));
  line.userData.life = 0.12; scene.add(line); disposableLines.push(line);
}
function showToast(message) {
  toastMessage = message; UI.toast.textContent = message; UI.toast.classList.add('show'); toastUntil = performance.now() + 1900;
}
function beep(freq = 220, duration = 0.055, volume = 0.025) {
  if (!soundOn) return;
  try {
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioContext.createOscillator(), gain = audioContext.createGain();
    osc.type = 'triangle'; osc.frequency.value = freq; gain.gain.value = volume; osc.connect(gain); gain.connect(audioContext.destination); osc.start();
    gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + duration); osc.stop(audioContext.currentTime + duration);
  } catch { /* audio is optional */ }
}
function updateHud() {
  UI.health.textContent = Math.max(0, Math.ceil(health)); UI.healthFill.style.width = `${Math.max(0, health)}%`;
  UI.alive.textContent = String(1 + bots.filter(b => b.alive).length).padStart(2, '0');
  UI.kills.textContent = String(kills).padStart(2, '0');
  UI.ammo.innerHTML = `${String(ammo).padStart(2, '0')}<small>${reloading ? 'إعادة تعبئة…' : 'ذخيرة · AR'}</small>`;
  UI.runState.textContent = (keys.ShiftLeft || keys.ShiftRight) ? 'نشط' : 'جاهز';
}
function startGame() {
  gameState = 'playing'; gameTime = 0; kills = 0; health = 100; ammo = 30; reloading = false; fireCooldown = 0; grounded = true; jumpVelocity = 0;
  player.alive = true; player.x = 0; player.z = 27; player.baseY = terrainHeight(0, 27); player.group.position.set(player.x, player.baseY, player.z);
  yaw = 0; pitch = 0.16; makeBots(); setZoneRadius(145);
  UI.intro.classList.add('hidden'); UI.menu.classList.add('hidden'); UI.settings.classList.add('hidden'); UI.about.classList.add('hidden'); UI.gameOver.classList.add('hidden'); UI.hud.classList.remove('hidden'); UI.hint.style.display = 'block';
  showToast('تحرّك، اجمع عتادك، وابقَ داخل المنطقة'); updateHud(); updateMinimap();
}
function returnMenu() {
  gameState = 'menu'; document.exitPointerLock?.(); UI.hud.classList.add('hidden'); UI.gameOver.classList.add('hidden');
  UI.menu.classList.remove('hidden'); UI.settings.classList.add('hidden'); UI.about.classList.add('hidden'); UI.intro.classList.add('hidden');
}
function finishGame(won) {
  if (gameState !== 'playing') return;
  gameState = 'over'; document.exitPointerLock?.(); UI.hint.style.display = 'none'; UI.gameOver.classList.remove('hidden');
  $('endTitle').textContent = won ? 'بطل الميدان' : 'انتهت المعركة';
  $('endSubtitle').textContent = won ? `أقصيت كل الخصوم. عدد الإقصاءات: ${kills}` : `الإقصاءات: ${kills} — جولة أخرى، وخطة أفضل.`;
  beep(won ? 560 : 110, 0.22, 0.045);
}
function shoot() {
  if (gameState !== 'playing' || !player.alive || reloading || fireCooldown > 0) return;
  if (ammo <= 0) { showToast('الذخيرة فارغة — اضغط R للتعبئة'); beep(90, 0.05); return; }
  ammo--; fireCooldown = 0.18; beep(165, 0.045, 0.018);
  const ray = new THREE.Raycaster(); ray.setFromCamera(new THREE.Vector2(0, 0), camera);
  const meshes = []; for (const bot of bots) if (bot.alive) for (const mesh of bot.meshes) if (mesh.isMesh) meshes.push(mesh);
  const hits = ray.intersectObjects(meshes, false);
  let endPoint = ray.ray.origin.clone().add(ray.ray.direction.clone().multiplyScalar(95));
  if (hits.length) {
    endPoint = hits[0].point.clone(); const bot = hits[0].object.userData.bot;
    if (bot && bot.alive) {
      bot.hp -= 34; beep(310, 0.06, 0.018);
      if (bot.hp <= 0) { bot.alive = false; scene.remove(bot.group); kills++; showToast('خصم خرج من الميدان'); beep(480, 0.1, 0.035); }
    }
  }
  addTracer(new THREE.Vector3(player.x + 0.4, player.group.position.y + 1.25, player.z - 0.5), endPoint);
  updateHud();
}
function reload() {
  if (reloading || ammo === 30 || gameState !== 'playing') return;
  reloading = true; reloadAt = performance.now() + 1450; showToast('إعادة تعبئة الذخيرة…'); beep(290, 0.08, 0.02); updateHud();
}
function updatePlayer(dt) {
  const forward = (keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0) - touchMove.y;
  const strafe = (keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0) + touchMove.x;
  const length = Math.hypot(forward, strafe); let dx = 0, dz = 0;
  if (length > 0.04) {
    const f = forward / Math.max(1, length), s = strafe / Math.max(1, length);
    dx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
    dz = -Math.cos(yaw) * f - Math.sin(yaw) * s;
    const mag = Math.hypot(dx, dz) || 1; dx /= mag; dz /= mag;
    const speed = keys.ShiftLeft || keys.ShiftRight ? 9.3 : 6.1;
    player.x += dx * speed * dt; player.z += dz * speed * dt;
    player.group.rotation.y = Math.atan2(dx, dz);
  }
  player.x = THREE.MathUtils.clamp(player.x, -163, 163); player.z = THREE.MathUtils.clamp(player.z, -163, 163);
  if (jumpQueued && grounded) { jumpVelocity = 6.8; grounded = false; }
  jumpQueued = false;
  jumpVelocity -= 17 * dt;
  const floorY = terrainHeight(player.x, player.z); let py = player.group.position.y + jumpVelocity * dt;
  if (py <= floorY) { py = floorY; jumpVelocity = 0; grounded = true; }
  player.group.position.set(player.x, py, player.z); player.baseY = floorY;
  const cameraOffset = new THREE.Vector3(Math.sin(yaw) * 8.4, 4.2 + pitch * 4, Math.cos(yaw) * 8.4);
  const target = player.group.position.clone().add(cameraOffset);
  camera.position.lerp(target, 1 - Math.pow(0.0004, dt));
  camera.lookAt(player.x, py + 1.05, player.z);
  if (fireHeld) shoot();
  if (fireCooldown > 0) fireCooldown -= dt;
  if (reloading && performance.now() >= reloadAt) { ammo = 30; reloading = false; showToast('تمت تعبئة الذخيرة'); beep(420, 0.07, 0.025); }
}
function updateBots(dt) {
  for (const bot of bots) {
    if (!bot.alive) continue;
    bot.cool -= dt; const dx = player.x - bot.x, dz = player.z - bot.z, distance = Math.hypot(dx, dz);
    if (distance < 82 && distance > 6) {
      const speed = distance > 18 ? 2.65 : 0.65;
      bot.x += dx / distance * speed * dt; bot.z += dz / distance * speed * dt;
      bot.group.rotation.y = Math.atan2(dx, dz); bot.group.position.x = bot.x; bot.group.position.z = bot.z;
      bot.group.position.y = terrainHeight(bot.x, bot.z) + Math.sin(gameTime * 3 + bot.seed) * 0.025;
    }
    if (distance < 30 && bot.cool <= 0) {
      bot.cool = 1.2 + random() * 1.4; health = Math.max(0, health - (distance < 14 ? 7 : 4));
      addTracer(new THREE.Vector3(bot.x, bot.group.position.y + 1.35, bot.z), new THREE.Vector3(player.x, player.group.position.y + 1.2, player.z), 0xd77a5e);
      if (health <= 0) { player.alive = false; finishGame(false); return; }
    }
  }
  if (bots.every(bot => !bot.alive)) finishGame(true);
}
function updateZone(dt) {
  const radius = Math.max(42, 145 - gameTime * 0.17);
  if (gameTime - zoneUpdateTime > 1.2) { setZoneRadius(radius); zoneUpdateTime = gameTime; }
  if (Math.hypot(player.x, player.z) > radius) {
    health = Math.max(0, health - 5 * dt); UI.zoneStatus.textContent = 'خارج المنطقة!'; UI.zoneStatus.style.color = '#ff8475';
    if (health <= 0) finishGame(false);
  } else { UI.zoneStatus.textContent = 'داخل المنطقة'; UI.zoneStatus.style.color = ''; }
  const remaining = Math.max(0, Math.ceil((145 - 42) / 0.17 - gameTime));
  UI.zoneTime.textContent = `${String(Math.floor(remaining / 60)).padStart(2, '0')}:${String(remaining % 60).padStart(2, '0')}`;
}
function updateMinimap() {
  const mini = $('minimap'), ctx = mini.getContext('2d'), w = mini.width, h = mini.height, scale = w / 330;
  ctx.clearRect(0, 0, w, h); ctx.fillStyle = 'rgba(12,31,30,.96)'; ctx.fillRect(0, 0, w, h); ctx.strokeStyle = 'rgba(163,190,161,.15)';
  for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo(i * w / 4, 0); ctx.lineTo(i * w / 4, h); ctx.moveTo(0, i * h / 4); ctx.lineTo(w, i * h / 4); ctx.stroke(); }
  ctx.strokeStyle = '#d9c27e'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(w / 2, h / 2, safeRadius * scale, 0, Math.PI * 2); ctx.stroke();
  for (const b of bots) if (b.alive) { ctx.fillStyle = '#ed7668'; ctx.beginPath(); ctx.arc(w / 2 + b.x * scale, h / 2 + b.z * scale, 2.6, 0, Math.PI * 2); ctx.fill(); }
  ctx.fillStyle = '#f6e7b8'; ctx.beginPath(); ctx.arc(w / 2 + player.x * scale, h / 2 + player.z * scale, 4, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = '#f6e7b8'; ctx.beginPath(); ctx.moveTo(w / 2 + player.x * scale, h / 2 + player.z * scale); ctx.lineTo(w / 2 + (player.x - Math.sin(yaw) * 9) * scale, h / 2 + (player.z - Math.cos(yaw) * 9) * scale); ctx.stroke();
}
function updateTracers(dt) {
  for (let i = disposableLines.length - 1; i >= 0; i--) {
    const line = disposableLines[i]; line.userData.life -= dt;
    if (line.userData.life <= 0) { scene.remove(line); line.geometry.dispose(); line.material.dispose(); disposableLines.splice(i, 1); }
    else line.material.opacity = Math.max(0, line.userData.life / 0.12);
  }
}

$('startGame').addEventListener('click', startGame);
$('restartGame').addEventListener('click', startGame);
$('backMenu').addEventListener('click', returnMenu);
$('skipIntro').addEventListener('click', () => { UI.intro.classList.add('hidden'); UI.menu.classList.remove('hidden'); });
$('openSettings').addEventListener('click', () => UI.settings.classList.remove('hidden'));
$('openAbout').addEventListener('click', () => UI.about.classList.remove('hidden'));
$('closeSettings').addEventListener('click', () => UI.settings.classList.add('hidden'));
$('closeAbout').addEventListener('click', () => UI.about.classList.add('hidden'));
$('quality').addEventListener('change', event => {
  quality = event.target.value; renderer.shadowMap.enabled = quality !== 'low';
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, quality === 'low' ? 0.85 : quality === 'medium' ? 1.2 : 1.6));
  renderer.setSize(innerWidth, innerHeight);
});
$('sensitivity').addEventListener('input', event => sensitivity = Number(event.target.value));
$('soundToggle').addEventListener('click', () => { soundOn = !soundOn; $('soundToggle').textContent = soundOn ? 'إيقاف الصوت' : 'تشغيل الصوت'; if (soundOn) beep(460, 0.08, 0.03); });
$('jumpBtn').addEventListener('pointerdown', event => { event.preventDefault(); jumpQueued = true; });
$('reloadBtn').addEventListener('pointerdown', event => { event.preventDefault(); reload(); });
$('fireBtn').addEventListener('pointerdown', event => { event.preventDefault(); fireHeld = true; try { $('fireBtn').setPointerCapture(event.pointerId); } catch {} });
$('fireBtn').addEventListener('pointerup', () => fireHeld = false); $('fireBtn').addEventListener('pointercancel', () => fireHeld = false); $('fireBtn').addEventListener('lostpointercapture', () => fireHeld = false);
canvas.addEventListener('click', () => { if (gameState === 'playing' && innerWidth > 720 && document.pointerLockElement !== canvas) canvas.requestPointerLock?.(); });
document.addEventListener('mousemove', event => {
  if (gameState === 'playing' && document.pointerLockElement === canvas) { yaw -= event.movementX * 0.0024 * sensitivity; pitch = THREE.MathUtils.clamp(pitch + event.movementY * 0.0016 * sensitivity, -0.05, 0.52); }
});
document.addEventListener('keydown', event => {
  keys[event.code] = true;
  if (event.code === 'Space') jumpQueued = true;
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.code)) event.preventDefault();
  if (event.code === 'KeyR') reload();
  if (event.code === 'Escape') { fireHeld = false; }
});
document.addEventListener('keyup', event => { keys[event.code] = false; });
canvas.addEventListener('pointerdown', event => {
  if (gameState !== 'playing') return;
  if (event.pointerType === 'touch') { lastTouchX = event.clientX; lastTouchY = event.clientY; touchDragging = true; }
  else if (event.button === 0) fireHeld = true;
});
canvas.addEventListener('pointermove', event => {
  if (gameState === 'playing' && event.pointerType === 'touch' && touchDragging) {
    yaw -= (event.clientX - lastTouchX) * 0.006 * sensitivity;
    pitch = THREE.MathUtils.clamp(pitch + (event.clientY - lastTouchY) * 0.003 * sensitivity, -0.03, 0.5);
    lastTouchX = event.clientX; lastTouchY = event.clientY;
  }
});
for (const ev of ['pointerup', 'pointercancel', 'pointerleave']) canvas.addEventListener(ev, () => { touchDragging = false; fireHeld = false; });
const joystick = $('joystick'), stick = $('stick');
function updateJoystick(event) {
  const rect = joystick.getBoundingClientRect(), cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
  const dx = event.clientX - cx, dy = event.clientY - cy, limit = rect.width * 0.34, len = Math.hypot(dx, dy) || 1, mag = Math.min(limit, len);
  touchMove.x = THREE.MathUtils.clamp(dx / limit, -1, 1); touchMove.y = THREE.MathUtils.clamp(dy / limit, -1, 1);
  stick.style.transform = `translate(calc(-50% + ${dx / len * mag}px),calc(-50% + ${dy / len * mag}px))`;
}
function resetJoystick() { joystickPointer = null; touchMove.x = 0; touchMove.y = 0; stick.style.transform = 'translate(-50%,-50%)'; }
joystick.addEventListener('pointerdown', event => { event.preventDefault(); joystickPointer = event.pointerId; joystick.setPointerCapture(event.pointerId); updateJoystick(event); });
joystick.addEventListener('pointermove', event => { if (event.pointerId === joystickPointer) updateJoystick(event); });
['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => joystick.addEventListener(ev, resetJoystick));
window.addEventListener('blur', () => { fireHeld = false; resetJoystick(); for (const key in keys) keys[key] = false; });
window.addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); renderer.setPixelRatio(Math.min(devicePixelRatio || 1, quality === 'low' ? 0.85 : quality === 'medium' ? 1.2 : 1.6)); });
setTimeout(() => { if (gameState === 'menu') { UI.intro.classList.add('hidden'); UI.menu.classList.remove('hidden'); } }, 4300);

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(0.05, clock.getDelta());
  if (gameState === 'playing') {
    gameTime += dt; updatePlayer(dt);
    if (gameState === 'playing') { updateBots(dt); updateZone(dt); updateHud(); if (gameTime - minimapUpdateTime > 0.16) { updateMinimap(); minimapUpdateTime = gameTime; } }
  } else {
    const time = performance.now() * 0.00008;
    camera.position.lerp(new THREE.Vector3(Math.sin(time) * 83, 35, Math.cos(time) * 83), 0.014);
    camera.lookAt(0, 2, 0);
  }
  updateTracers(dt);
  if (performance.now() > toastUntil) UI.toast.classList.remove('show');
  renderer.render(scene, camera);
}
updateHud(); updateMinimap(); camera.position.set(0, 38, 86); camera.lookAt(0, 2, 0); requestAnimationFrame(animate);
