using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public sealed class SaqoorPlayerController : MonoBehaviour
{
    private SaqoorBootstrap game;
    private Camera view;
    private CharacterController controller;
    private float verticalVelocity, shootCooldown, yaw, pitch = 0.18f;
    private int moveFingerId = -1, lookFingerId = -1;
    private Vector2 moveTouchStart, moveTouchDelta, lookTouchLast;
    private bool touchShotQueued;

    public void Configure(SaqoorBootstrap owner, Camera cam) { game = owner; view = cam; }

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
        if (controller == null) controller = gameObject.AddComponent<CharacterController>();
        controller.height = 2f; controller.radius = .42f; controller.center = new Vector3(0f, 1f, 0f);
    }

    private void Update()
    {
        if (game == null || !game.IsPlaying || controller == null) return;

        // Desktop camera controls: hold the right mouse button and move the mouse.
        if (Input.GetMouseButton(1))
        {
            yaw += Input.GetAxis("Mouse X") * 2.2f;
            pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * 1.4f, -0.15f, .6f);
        }

        // Android/touch fallback: left half of the screen moves, right half looks around.
        for (int i = 0; i < Input.touchCount; i++)
        {
            Touch touch = Input.GetTouch(i);
            if (touch.phase == TouchPhase.Began)
            {
                if (touch.position.x < Screen.width * .45f && moveFingerId == -1)
                {
                    moveFingerId = touch.fingerId;
                    moveTouchStart = touch.position;
                    moveTouchDelta = Vector2.zero;
                }
                else if (touch.position.x >= Screen.width * .45f && lookFingerId == -1)
                {
                    lookFingerId = touch.fingerId;
                    lookTouchLast = touch.position;
                }
            }
            else if (touch.fingerId == moveFingerId)
            {
                moveTouchDelta = Vector2.ClampMagnitude(touch.position - moveTouchStart, 90f);
                if (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled)
                {
                    moveFingerId = -1;
                    moveTouchDelta = Vector2.zero;
                }
            }
            else if (touch.fingerId == lookFingerId)
            {
                Vector2 delta = touch.position - lookTouchLast;
                yaw += delta.x * .12f;
                pitch = Mathf.Clamp(pitch - delta.y * .0017f, -.15f, .6f);
                lookTouchLast = touch.position;
                if (touch.phase == TouchPhase.Ended || touch.phase == TouchPhase.Canceled)
                {
                    if (delta.sqrMagnitude < 64f) touchShotQueued = true;
                    lookFingerId = -1;
                }
            }
        }

        Vector2 raw = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        if (moveFingerId != -1) raw = new Vector2(moveTouchDelta.x, moveTouchDelta.y) / 70f;
        Vector3 input = new Vector3(raw.x, 0f, raw.y);
        if (input.sqrMagnitude > 1f) input.Normalize();
        Vector3 move = Quaternion.Euler(0f, yaw, 0f) * input;
        float speed = Input.GetKey(KeyCode.LeftShift) ? 8.5f : 5.2f;
        controller.Move(move * speed * Time.deltaTime);
        if (move.sqrMagnitude > .02f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(move), Time.deltaTime * 9f);
        if (controller.isGrounded && verticalVelocity < 0f) verticalVelocity = -1f;
        if (controller.isGrounded && Input.GetKeyDown(KeyCode.Space)) verticalVelocity = 6.2f;
        verticalVelocity += Physics.gravity.y * Time.deltaTime;
        controller.Move(Vector3.up * verticalVelocity * Time.deltaTime);

        if (view != null)
        {
            Vector3 offset = Quaternion.Euler(pitch * 70f, yaw, 0f) * new Vector3(0f, 3.1f, -7.5f);
            view.transform.position = Vector3.Lerp(view.transform.position, transform.position + offset, Time.deltaTime * 7f);
            view.transform.LookAt(transform.position + Vector3.up * 1.3f);
        }

        shootCooldown -= Time.deltaTime;
        bool wantsToShoot = Input.GetMouseButton(0) || touchShotQueued;
        touchShotQueued = false;
        if (wantsToShoot && shootCooldown <= 0f)
        {
            shootCooldown = .18f;
            if (!game.TrySpendAmmo()) return;
            Ray ray = view != null ? view.ViewportPointToRay(new Vector3(.5f, .5f, 0f)) : new Ray(transform.position + Vector3.up, transform.forward);
            if (Physics.Raycast(ray, out RaycastHit hit, 130f))
            {
                SaqoorBot bot = hit.collider.GetComponentInParent<SaqoorBot>();
                if (bot != null) bot.TakeHit(34f);
            }
        }
    }
}
