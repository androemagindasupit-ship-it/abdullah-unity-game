using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

/// <summary>Builds a lightweight procedural Saqoor prototype without external 3D assets.</summary>
public sealed class SaqoorBootstrap : MonoBehaviour
{
    public static SaqoorBootstrap Instance { get; private set; }
    private readonly List<SaqoorBot> bots = new List<SaqoorBot>();
    private Transform player;
    private Camera gameCamera;
    private Canvas canvas;
    private Text statusText, healthText, ammoText;
    private GameObject introPanel, hudPanel, endPanel;
    private Image introLogo;
    private float health = 100f, roundTime, zoneRadius = 145f;
    private int ammo = 30, kills;
    private bool playing, ending;
    private Material groundMat, wallMat, foliageMat, goldMat;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        BuildWorld();
        BuildPlayer();
        BuildBots();
        BuildUI();
        ShowIntro();
    }

    private void BuildWorld()
    {
        RenderSettings.ambientLight = new Color(.56f, .62f, .55f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(.58f, .71f, .71f);
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = .003f;
        groundMat = CreateMaterial(new Color(.31f, .42f, .28f));
        wallMat = CreateMaterial(new Color(.48f, .46f, .36f));
        foliageMat = CreateMaterial(new Color(.13f, .25f, .17f));
        goldMat = CreateMaterial(new Color(.83f, .68f, .36f), .15f);

        GameObject sunObject = new GameObject("Warm directional light");
        Light sun = sunObject.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.intensity = 1.3f;
        sun.color = new Color(1f, .87f, .68f);
        sun.transform.rotation = Quaternion.Euler(48f, -32f, 0f);
        sun.shadows = LightShadows.Soft;

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Training island";
        ground.transform.localScale = new Vector3(36f, 1f, 36f);
        ground.GetComponent<Renderer>().sharedMaterial = groundMat;
        GameObject sea = GameObject.CreatePrimitive(PrimitiveType.Plane);
        sea.name = "Sea";
        sea.transform.position = new Vector3(0f, -3f, 0f);
        sea.transform.localScale = new Vector3(80f, 1f, 80f);
        sea.GetComponent<Renderer>().sharedMaterial = CreateMaterial(new Color(.12f, .32f, .36f), .3f);

        System.Random random = new System.Random(1884);
        for (int i = 0; i < 46; i++)
        {
            float angle = (float)random.NextDouble() * Mathf.PI * 2f;
            float distance = 18f + (float)random.NextDouble() * 118f;
            Vector3 p = new Vector3(Mathf.Cos(angle) * distance, 0f, Mathf.Sin(angle) * distance);
            MakeTree(p, .7f + (float)random.NextDouble() * .6f);
        }
        MakeBuilding(new Vector3(-40f, 0f, -10f), new Vector3(15f, 6f, 12f));
        MakeBuilding(new Vector3(26f, 0f, -28f), new Vector3(13f, 5f, 14f));
        MakeBuilding(new Vector3(53f, 0f, 22f), new Vector3(16f, 7f, 12f));
        MakeBuilding(new Vector3(-70f, 0f, 36f), new Vector3(12f, 5f, 10f));
        MakeCrate(new Vector3(-15f, .7f, 27f));
        MakeCrate(new Vector3(42f, .7f, 10f));
        MakeCrate(new Vector3(-65f, .7f, -35f));
    }

    private static Material CreateMaterial(Color color, float metallic = 0f)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        Material material = new Material(shader);
        material.color = color;
        if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metallic);
        return material;
    }

    private void MakeTree(Vector3 position, float scale)
    {
        GameObject root = new GameObject("Pine tree");
        root.transform.position = position;
        root.transform.localScale = Vector3.one * scale;
        GameObject trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        RemoveCollider(trunk);
        trunk.transform.SetParent(root.transform, false);
        trunk.transform.localPosition = new Vector3(0f, 1.1f, 0f);
        trunk.transform.localScale = new Vector3(.22f, 1.1f, .22f);
        trunk.GetComponent<Renderer>().sharedMaterial = CreateMaterial(new Color(.29f, .22f, .15f));
        for (int i = 0; i < 3; i++)
        {
            GameObject top = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            RemoveCollider(top);
            top.transform.SetParent(root.transform, false);
            top.transform.localPosition = new Vector3(0f, 2f + i * .65f, 0f);
            top.transform.localScale = new Vector3(1.5f - i * .22f, 1.2f, 1.5f - i * .22f);
            top.GetComponent<Renderer>().sharedMaterial = foliageMat;
        }
    }

    private void MakeBuilding(Vector3 position, Vector3 size)
    {
        GameObject building = GameObject.CreatePrimitive(PrimitiveType.Cube);
        building.name = "Outpost";
        building.transform.position = position + Vector3.up * size.y * .5f;
        building.transform.localScale = size;
        building.GetComponent<Renderer>().sharedMaterial = wallMat;
        GameObject roof = GameObject.CreatePrimitive(PrimitiveType.Cube);
        roof.name = "Outpost roof";
        roof.transform.position = position + Vector3.up * (size.y + .15f);
        roof.transform.localScale = new Vector3(size.x + .5f, .3f, size.z + .5f);
        roof.GetComponent<Renderer>().sharedMaterial = CreateMaterial(new Color(.17f, .2f, .18f));
    }

    private void MakeCrate(Vector3 position)
    {
        GameObject crate = GameObject.CreatePrimitive(PrimitiveType.Cube);
        crate.name = "Supply crate";
        crate.transform.position = position;
        crate.transform.localScale = new Vector3(1.8f, 1.4f, 1.6f);
        crate.GetComponent<Renderer>().sharedMaterial = goldMat;
    }

    private void BuildPlayer()
    {
        player = new GameObject("Player — Saqoor").transform;
        player.position = new Vector3(0f, 0f, 27f);
        CharacterController controller = player.gameObject.AddComponent<CharacterController>();
        controller.height = 2f; controller.radius = .42f; controller.center = new Vector3(0f, 1f, 0f);
        MakeSoldierVisual(player, new Color(.15f, .29f, .27f), new Color(.85f, .68f, .34f));
        GameObject camObject = new GameObject("Saqoor third-person camera");
        gameCamera = camObject.AddComponent<Camera>();
        gameCamera.fieldOfView = 65f;
        camObject.AddComponent<AudioListener>();
        player.gameObject.AddComponent<SaqoorPlayerController>().Configure(this, gameCamera);
        camObject.transform.position = player.position + new Vector3(0f, 4f, 8f);
        camObject.transform.LookAt(player.position + Vector3.up * 1.1f);
    }

    private void MakeSoldierVisual(Transform root, Color uniform, Color trim)
    {
        GameObject body = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        RemoveCollider(body); body.name = "Armoured body"; body.transform.SetParent(root, false);
        body.transform.localPosition = new Vector3(0f, .95f, 0f); body.transform.localScale = new Vector3(.72f, .68f, .72f);
        body.GetComponent<Renderer>().sharedMaterial = CreateMaterial(uniform);
        GameObject vest = GameObject.CreatePrimitive(PrimitiveType.Cube);
        RemoveCollider(vest); vest.transform.SetParent(root, false); vest.transform.localPosition = new Vector3(0f, 1.08f, .1f);
        vest.transform.localScale = new Vector3(.67f, .58f, .34f); vest.GetComponent<Renderer>().sharedMaterial = CreateMaterial(new Color(.09f, .14f, .14f));
        GameObject head = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        RemoveCollider(head); head.transform.SetParent(root, false); head.transform.localPosition = new Vector3(0f, 1.76f, 0f);
        head.transform.localScale = Vector3.one * .42f; head.GetComponent<Renderer>().sharedMaterial = CreateMaterial(new Color(.52f, .39f, .28f));
        GameObject helmet = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        RemoveCollider(helmet); helmet.transform.SetParent(root, false); helmet.transform.localPosition = new Vector3(0f, 1.88f, 0f);
        helmet.transform.localScale = new Vector3(.48f, .28f, .45f); helmet.GetComponent<Renderer>().sharedMaterial = CreateMaterial(trim);
    }

    private static void RemoveCollider(GameObject target)
    {
        Collider collider = target.GetComponent<Collider>();
        if (collider != null) Destroy(collider);
    }

    private void BuildBots()
    {
        for (int i = 0; i < 8; i++)
        {
            float angle = i * Mathf.PI * 2f / 8f;
            Vector3 position = new Vector3(Mathf.Cos(angle) * (42f + (i % 3) * 13f), 0f, Mathf.Sin(angle) * (42f + (i % 3) * 13f));
            GameObject botObject = new GameObject("Training opponent " + (i + 1));
            botObject.transform.position = position;
            CapsuleCollider collider = botObject.AddComponent<CapsuleCollider>(); collider.height = 2f; collider.radius = .42f; collider.center = Vector3.up;
            MakeSoldierVisual(botObject.transform, new Color(.38f, .2f, .17f), new Color(.56f, .47f, .31f));
            SaqoorBot bot = botObject.AddComponent<SaqoorBot>();
            bot.Configure(this, player, position);
            bots.Add(bot);
        }
    }

    private void BuildUI()
    {
        GameObject eventObject = new GameObject("EventSystem");
        eventObject.AddComponent<EventSystem>(); eventObject.AddComponent<StandaloneInputModule>();
        GameObject canvasObject = new GameObject("Saqoor UI");
        canvas = canvasObject.AddComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasObject.AddComponent<CanvasScaler>(); scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080); canvasObject.AddComponent<GraphicRaycaster>();
        introPanel = CreatePanel(canvasObject.transform, new Color(.025f, .055f, .055f, .96f));
        CanvasGroup introGroup = introPanel.AddComponent<CanvasGroup>(); introGroup.alpha = 0f;
        Texture2D logoTexture = Resources.Load<Texture2D>("saqoor-splash");
        if (logoTexture != null)
        {
            GameObject logoObject = new GameObject("Arabic logo — تطوير عبدالله لازم"); logoObject.transform.SetParent(introPanel.transform, false);
            RectTransform logoRect = logoObject.AddComponent<RectTransform>();
            logoRect.anchorMin = new Vector2(.1f, .34f); logoRect.anchorMax = new Vector2(.9f, .78f);
            logoRect.offsetMin = Vector2.zero; logoRect.offsetMax = Vector2.zero;
            Image logoImage = logoObject.AddComponent<Image>(); logoImage.preserveAspect = true;
            logoImage.sprite = Sprite.Create(logoTexture, new Rect(0, 0, logoTexture.width, logoTexture.height), new Vector2(.5f, .5f), 100f);
            introLogo = logoImage;
        }
        Label(introPanel.transform, "SAQOOR · SURVIVAL PROJECT", 20, new Vector2(0f, .28f), new Vector2(1f, .38f), new Color(.56f, .75f, .64f), TextAnchor.MiddleCenter);
        MakeButton(introPanel.transform, "START BATTLE", new Vector2(.5f, .16f), StartRound);
        hudPanel = CreatePanel(canvasObject.transform, new Color(0f, 0f, 0f, .20f));
        statusText = Label(hudPanel.transform, "OPPONENTS 08  |  ELIMINATIONS 00", 24, new Vector2(.02f, .88f), new Vector2(.65f, .98f), Color.white, TextAnchor.UpperLeft);
        healthText = Label(hudPanel.transform, "HEALTH 100", 26, new Vector2(.02f, .06f), new Vector2(.35f, .16f), new Color(1f, .88f, .62f), TextAnchor.LowerLeft);
        ammoText = Label(hudPanel.transform, "AMMO 30  ·  WASD / R / SHIFT", 20, new Vector2(.62f, .06f), new Vector2(.98f, .16f), Color.white, TextAnchor.LowerRight);
        endPanel = CreatePanel(canvasObject.transform, new Color(.015f, .03f, .03f, .94f));
        Label(endPanel.transform, "ROUND COMPLETE", 58, new Vector2(0f, .53f), new Vector2(1f, .7f), new Color(1f, .83f, .5f), TextAnchor.MiddleCenter);
        MakeButton(endPanel.transform, "RETURN TO INTRO", new Vector2(.5f, .38f), ShowIntro);
        hudPanel.SetActive(false); endPanel.SetActive(false);
    }

    private GameObject CreatePanel(Transform parent, Color color)
    {
        GameObject panel = new GameObject("Panel"); panel.transform.SetParent(parent, false);
        RectTransform rect = panel.AddComponent<RectTransform>(); rect.anchorMin = Vector2.zero; rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero; rect.offsetMax = Vector2.zero; panel.AddComponent<Image>().color = color;
        return panel;
    }

    private Text Label(Transform parent, string value, int size, Vector2 min, Vector2 max, Color color, TextAnchor anchor)
    {
        GameObject obj = new GameObject("Text"); obj.transform.SetParent(parent, false);
        RectTransform rect = obj.AddComponent<RectTransform>(); rect.anchorMin = min; rect.anchorMax = max;
        rect.offsetMin = new Vector2(10, 4); rect.offsetMax = new Vector2(-10, -4);
        Text text = obj.AddComponent<Text>(); text.text = value; text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        text.fontSize = size; text.alignment = anchor; text.color = color; text.horizontalOverflow = HorizontalWrapMode.Wrap;
        text.verticalOverflow = VerticalWrapMode.Overflow; text.fontStyle = FontStyle.Bold; return text;
    }

    private Button MakeButton(Transform parent, string value, Vector2 anchor, UnityEngine.Events.UnityAction action)
    {
        GameObject obj = new GameObject("Button — " + value); obj.transform.SetParent(parent, false);
        RectTransform rect = obj.AddComponent<RectTransform>(); rect.anchorMin = anchor; rect.anchorMax = anchor;
        rect.pivot = new Vector2(.5f, .5f); rect.anchoredPosition = Vector2.zero; rect.sizeDelta = new Vector2(360, 76);
        Image image = obj.AddComponent<Image>(); image.color = new Color(.78f, .61f, .29f, .98f);
        Button button = obj.AddComponent<Button>(); button.targetGraphic = image; button.onClick.AddListener(action);
        Label(obj.transform, value, 27, Vector2.zero, Vector2.one, new Color(.045f, .07f, .065f), TextAnchor.MiddleCenter);
        return button;
    }

    private void ShowIntro()
    {
        playing = false; ending = false;
        if (introPanel != null) introPanel.SetActive(true);
        if (hudPanel != null) hudPanel.SetActive(false);
        if (endPanel != null) endPanel.SetActive(false);
        if (player != null) player.position = new Vector3(0f, 0f, 27f);
        StopAllCoroutines(); StartCoroutine(AnimateIntro());
    }

    private System.Collections.IEnumerator AnimateIntro()
    {
        CanvasGroup group = introPanel.GetComponent<CanvasGroup>();
        introPanel.transform.localScale = Vector3.one * .90f; group.alpha = 0f;
        float time = 0f;
        while (time < 1.2f && introPanel.activeSelf)
        {
            time += Time.unscaledDeltaTime; float t = Mathf.SmoothStep(0f, 1f, time / 1.2f);
            group.alpha = t; introPanel.transform.localScale = Vector3.Lerp(Vector3.one * .90f, Vector3.one, t); yield return null;
        }
        group.alpha = 1f; introPanel.transform.localScale = Vector3.one;
    }

    public void StartRound()
    {
        health = 100f; ammo = 30; kills = 0; roundTime = 0f; zoneRadius = 145f; playing = true; ending = false;
        player.position = new Vector3(0f, 0f, 27f);
        foreach (SaqoorBot bot in bots) if (bot != null) bot.ResetBot();
        introPanel.SetActive(false); endPanel.SetActive(false); hudPanel.SetActive(true);
    }

    public void RegisterKill(SaqoorBot bot)
    {
        if (bot == null || !bot.IsAlive) return;
        bot.MarkDead(); kills++;
        if (RemainingBots() == 0) EndRound(true);
    }

    private int RemainingBots() { int count = 0; foreach (SaqoorBot bot in bots) if (bot != null && bot.IsAlive) count++; return count; }

    public void ApplyDamage(float amount)
    {
        if (!playing || ending) return;
        health = Mathf.Max(0f, health - amount);
        if (health <= 0f) EndRound(false);
    }

    private void EndRound(bool won)
    {
        if (ending) return; ending = true; playing = false;
        hudPanel.SetActive(false); endPanel.SetActive(true);
        Text title = endPanel.GetComponentInChildren<Text>();
        if (title != null) title.text = won ? "YOU ARE THE LAST FALCON" : "ROUND OVER";
    }

    public bool TrySpendAmmo()
    {
        if (ammo <= 0) return false;
        ammo--;
        return true;
    }

    public void ReloadAmmo() { ammo = 30; }
    public Camera GameCamera { get { return gameCamera; } }
    public Transform Player { get { return player; } }
    public bool IsPlaying { get { return playing && !ending; } }

    private void Update()
    {
        if (playing)
        {
            roundTime += Time.deltaTime; zoneRadius = Mathf.Max(42f, 145f - roundTime * .17f);
            if (player != null && new Vector2(player.position.x, player.position.z).magnitude > zoneRadius) ApplyDamage(Time.deltaTime * 5f);
            if (statusText != null) statusText.text = "OPPONENTS " + (RemainingBots() + 1).ToString("00") + "  |  ELIMINATIONS " + kills.ToString("00");
            if (healthText != null) healthText.text = "HEALTH " + Mathf.CeilToInt(health);
            if (ammoText != null) ammoText.text = "AMMO " + ammo + "  ·  R TO RELOAD";
            if (Input.GetKeyDown(KeyCode.R)) ReloadAmmo();
        }
        else if (gameCamera != null && player != null)
        {
            float angle = Time.unscaledTime * .075f;
            gameCamera.transform.position = Vector3.Lerp(gameCamera.transform.position, new Vector3(Mathf.Sin(angle) * 82f, 34f, Mathf.Cos(angle) * 82f), Time.unscaledDeltaTime * 1.5f);
            gameCamera.transform.LookAt(Vector3.up * 2f);
        }
    }
}
