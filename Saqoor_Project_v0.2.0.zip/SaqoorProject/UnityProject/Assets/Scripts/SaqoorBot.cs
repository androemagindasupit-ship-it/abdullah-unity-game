using UnityEngine;

[RequireComponent(typeof(CapsuleCollider))]
public sealed class SaqoorBot : MonoBehaviour
{
    private SaqoorBootstrap game;
    private Transform target;
    private Vector3 spawnPoint;
    private float health = 100f, attackCooldown;
    public bool IsAlive { get; private set; } = true;

    public void Configure(SaqoorBootstrap owner, Transform player, Vector3 spawn)
    {
        game = owner; target = player; spawnPoint = spawn; health = 100f; IsAlive = true;
    }

    public void ResetBot()
    {
        health = 100f; IsAlive = true; attackCooldown = Random.Range(.5f, 1.5f);
        transform.position = spawnPoint; gameObject.SetActive(true);
    }

    public void TakeHit(float amount)
    {
        if (!IsAlive) return;
        health -= amount;
        if (health <= 0f && game != null) game.RegisterKill(this);
    }

    public void MarkDead()
    {
        IsAlive = false;
        gameObject.SetActive(false);
    }

    private void Update()
    {
        if (!IsAlive || game == null || !game.IsPlaying || target == null) return;
        Vector3 delta = target.position - transform.position; delta.y = 0f;
        float distance = delta.magnitude;
        if (distance < 85f && distance > 7f)
        {
            transform.position += delta.normalized * 2.5f * Time.deltaTime;
            if (delta.sqrMagnitude > .01f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(delta), Time.deltaTime * 3f);
        }
        attackCooldown -= Time.deltaTime;
        if (distance < 27f && attackCooldown <= 0f)
        {
            attackCooldown = Random.Range(1.2f, 2f);
            game.ApplyDamage(distance < 13f ? 7f : 4f);
        }
    }
}
