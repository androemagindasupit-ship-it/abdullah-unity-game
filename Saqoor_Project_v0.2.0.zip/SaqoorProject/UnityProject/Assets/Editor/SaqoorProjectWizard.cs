#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

[InitializeOnLoad]
public static class SaqoorProjectWizard
{
    private const string ScenePath = "Assets/Scenes/SaqoorArena.unity";
    static SaqoorProjectWizard() { EditorApplication.delayCall += CreateStarterSceneIfNeeded; }

    [MenuItem("Saqoor/Create Starter Scene")]
    public static void CreateStarterSceneIfNeeded()
    {
        if (File.Exists(ScenePath)) { AddSceneToBuildSettings(); return; }
        Directory.CreateDirectory("Assets/Scenes");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        GameObject root = new GameObject("SaqoorGame"); root.AddComponent<SaqoorBootstrap>();
        EditorSceneManager.SaveScene(scene, ScenePath);
        AddSceneToBuildSettings(); AssetDatabase.SaveAssets();
        Debug.Log("Saqoor Arena starter scene created: " + ScenePath);
    }

    private static void AddSceneToBuildSettings()
    {
        List<EditorBuildSettingsScene> scenes = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
        foreach (EditorBuildSettingsScene scene in scenes) if (scene.path == ScenePath && scene.enabled) return;
        scenes.RemoveAll(scene => scene.path == ScenePath);
        scenes.Insert(0, new EditorBuildSettingsScene(ScenePath, true));
        EditorBuildSettings.scenes = scenes.ToArray();
    }
}
#endif
