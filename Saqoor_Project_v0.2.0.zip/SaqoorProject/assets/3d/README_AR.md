# أصول 3D — ميدان الصقور

تحتوي الحزمة على ثلاثة أصول أصلية منخفضة التفاصيل، مولدة هندسياً ومتحقق من إمكانية تحميلها:

- `saqoor_falcon_emblem.glb` و`saqoor_falcon_emblem.obj/.mtl`: شعار صقر معدني ذهبي على قاعدة خضراء داكنة.
- `saqoor_operator.glb` و`saqoor_operator.obj/.mtl`: شخصية تدريبية بسيطة بخوذة ودرع وحقيبة وأجزاء منفصلة.
- `saqoor_supply_crate.glb` و`saqoor_supply_crate.obj/.mtl`: صندوق إمدادات مع أشرطة معدنية وشعار.

ملفات OBJ/MTL منسوخة أيضاً إلى `UnityProject/Assets/Models` ليستوردها Unity مباشرة. ملفات GLB مناسبة لبرامج مثل Blender ويمكن تعديلها/تحسينها. السكربت `BlenderTools/create_saqoor_assets.py` ينشئ نسخة Blender قابلة للتحرير مع خامات وإضاءة وكاميرا وتصدير GLB.

هذه نماذج أولية من نوع low-poly، وليست شخصية بشرية high-poly أو rigged أو animated. لا بد من إضافة skeleton وanimations وخامات وأصول إنتاجية واختبارات أداء قبل لعبة تجارية.
