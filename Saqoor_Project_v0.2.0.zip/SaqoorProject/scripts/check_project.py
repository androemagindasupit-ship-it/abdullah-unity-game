from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []
required = [
    "index.html", "src/game.js", "src/style.css", "assets/saqoor-mark.png",
    "assets/saqoor-splash.png", "UnityProject/Assets/Scripts/SaqoorBootstrap.cs",
    "UnityProject/Assets/Scripts/SaqoorPlayerController.cs",
    "UnityProject/Assets/Scripts/SaqoorBot.cs",
    "BlenderTools/create_saqoor_assets.py", "scripts/generate_glb_assets.py",
    "assets/3d/saqoor_falcon_emblem.glb", "assets/3d/saqoor_operator.glb",
    "assets/3d/saqoor_supply_crate.glb",
    "UnityProject/Assets/Models/saqoor_operator.obj", "UnityProject/Assets/Models/saqoor_operator.mtl",
]
for rel in required:
    if not (ROOT / rel).is_file():
        errors.append(f"Missing required file: {rel}")

html = (ROOT / "index.html").read_text(encoding="utf-8")
for attr, value in re.findall(r'\b(src|href)=["\']([^"\']+)["\']', html):
    if value.startswith(("https://", "http://", "data:", "#")):
        continue
    local = value.split("?", 1)[0].split("#", 1)[0]
    if local and not (ROOT / local).is_file():
        errors.append(f"Broken local {attr} reference in index.html: {local}")

for script_rel in ["BlenderTools/create_saqoor_assets.py", "scripts/generate_glb_assets.py"]:
    script = ROOT / script_rel
    if script.exists():
        try:
            compile(script.read_text(encoding="utf-8"), str(script), "exec")
        except SyntaxError as e:
            errors.append(f"Python script syntax error in {script_rel}: {e}")

try:
    import trimesh
    for rel in ["assets/3d/saqoor_falcon_emblem.glb", "assets/3d/saqoor_operator.glb", "assets/3d/saqoor_supply_crate.glb"]:
        path = ROOT / rel
        if path.exists():
            scene = trimesh.load(path, force="scene")
            if not scene.geometry:
                errors.append(f"Empty GLB model: {rel}")
except Exception as e:
    errors.append(f"GLB validation failed: {e}")

if errors:
    print("Project checks FAILED:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print("Project checks passed: required files, local HTML references, Python script syntax, and GLB load-back validation are successful.")
print("Note: these checks do not replace a real Unity editor/build test or running the Blender generator.")
