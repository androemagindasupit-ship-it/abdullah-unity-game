"""Generate small original Saqoor GLB starter meshes with trimesh.
The Blender-native editable source is BlenderTools/create_saqoor_assets.py.
This utility creates immediate lightweight GLB files for preview/import workflows.
"""
from pathlib import Path
import math
import numpy as np
import trimesh
from trimesh.visual.material import PBRMaterial

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets" / "3d"
OUT.mkdir(parents=True, exist_ok=True)

COLORS = {
    "gold": (222, 178, 86, 255),
    "pale_gold": (250, 225, 163, 255),
    "teal": (10, 35, 34, 255),
    "jade": (55, 137, 103, 255),
    "armor": (48, 75, 66, 255),
    "armor_light": (84, 103, 73, 255),
    "dark": (18, 27, 26, 255),
    "fabric": (35, 47, 42, 255),
    "skin": (139, 103, 76, 255),
    "crate": (56, 77, 48, 255),
    "red": (131, 62, 45, 255),
}

def pbr(name, color, metallic=.1, roughness=.55):
    return PBRMaterial(name=name, baseColorFactor=list(color), metallicFactor=metallic, roughnessFactor=roughness)

MATERIALS = {
    "gold": pbr("Saqoor brushed gold", COLORS["gold"], .72, .3),
    "pale_gold": pbr("Saqoor highlight gold", COLORS["pale_gold"], .65, .25),
    "teal": pbr("Deep teal enamel", COLORS["teal"], .35, .3),
    "jade": pbr("Jade accent", COLORS["jade"], .45, .3),
    "armor": pbr("Field green armor", COLORS["armor"], .18, .48),
    "armor_light": pbr("Olive armor panels", COLORS["armor_light"], .2, .48),
    "dark": pbr("Charcoal rubber and metal", COLORS["dark"], .18, .55),
    "fabric": pbr("Dark tactical fabric", COLORS["fabric"], .02, .8),
    "skin": pbr("Warm skin material", COLORS["skin"], .0, .65),
    "crate": pbr("Olive supply crate", COLORS["crate"], .15, .55),
    "red": pbr("Warning red detail", COLORS["red"], .1, .5),
}

def finish(mesh, name, material):
    mesh.metadata["name"] = name
    mesh.visual.material = MATERIALS[material]
    return mesh

def box(scene, name, dims, loc, material, rot_y=0):
    m = trimesh.creation.box(extents=dims)
    if rot_y:
        T = trimesh.transformations.rotation_matrix(rot_y, [0, 1, 0])
        m.apply_transform(T)
    m.apply_translation(loc)
    finish(m, name, material)
    scene.add_geometry(m, geom_name=name, node_name=name)
    return m

def sphere(scene, name, loc, scale, material, subdivisions=2):
    m = trimesh.creation.icosphere(subdivisions=subdivisions, radius=1.0)
    m.apply_scale(scale); m.apply_translation(loc)
    finish(m, name, material)
    scene.add_geometry(m, geom_name=name, node_name=name)
    return m

def cylinder(scene, name, radius, height, loc, material, axis="y", sections=12):
    if axis == "y":
        T = trimesh.transformations.rotation_matrix(math.pi / 2, [1, 0, 0])
        m = trimesh.creation.cylinder(radius=radius, height=height, sections=sections, transform=T)
    else:
        m = trimesh.creation.cylinder(radius=radius, height=height, sections=sections)
    m.apply_translation(loc)
    finish(m, name, material); scene.add_geometry(m, geom_name=name, node_name=name)
    return m

def polygon_extrude(name, points, depth, material):
    # Triangulate using Shapely's built-in Delaunay operation (no external triangulation engine).
    from shapely.geometry import Polygon
    from shapely.ops import triangulate
    poly = Polygon(points)
    base = [(float(x), float(y)) for x, y in points]
    index = { (round(x, 8), round(y, 8)): i for i, (x, y) in enumerate(base) }
    vertices = [(x, y, -depth / 2) for x, y in base] + [(x, y, depth / 2) for x, y in base]
    faces = []
    n = len(base)
    for tri in triangulate(poly):
        if not poly.covers(tri):
            continue
        coords = list(tri.exterior.coords)[:-1]
        ids = [index[(round(x, 8), round(y, 8))] for x, y in coords]
        faces.append(tuple(reversed(ids)))
        faces.append(tuple(i + n for i in ids))
    for i in range(n):
        j = (i + 1) % n
        faces.append((i, j, j + n))
        faces.append((i, j + n, i + n))
    mesh = trimesh.Trimesh(vertices=np.asarray(vertices), faces=np.asarray(faces), process=True)
    mesh.fix_normals()
    return finish(mesh, name, material)

def export(scene, filename):
    path = OUT / filename
    data = scene.export(file_type="glb")
    path.write_bytes(data if isinstance(data, bytes) else data.encode("utf-8"))
    # Load-back check helps catch malformed output containers.
    loaded = trimesh.load(path, force="scene")
    if not isinstance(loaded, trimesh.Scene) or not loaded.geometry:
        raise RuntimeError(f"Could not validate generated GLB: {path}")
    # An OBJ+MTL pair is included because Unity imports OBJ without an extra glTF package.
    stem = Path(filename).stem
    obj_text, sidecars = trimesh.exchange.obj.export_obj(scene, return_texture=True, mtl_name=stem + ".mtl")
    (OUT / (stem + ".obj")).write_text(obj_text, encoding="utf-8")
    for side_name, side_content in sidecars.items():
        if isinstance(side_content, bytes):
            (OUT / side_name).write_bytes(side_content)
        else:
            (OUT / side_name).write_text(side_content, encoding="utf-8")
    print(f"Created {path.name}: {path.stat().st_size:,} bytes, {len(loaded.geometry)} mesh objects")

# Emblem: raised gold falcon on a teal medallion, Y is vertical for game engines.
emblem = trimesh.Scene()
cylinder(emblem, "Medallion backing", 1.0, .18, (0, 0, 0), "teal", axis="z", sections=64)
for r, tube, depth, material in [(0.98, .026, .105, "pale_gold"), (.88, .012, .105, "gold")]:
    ring = trimesh.creation.torus(major_radius=r, minor_radius=tube, major_sections=64, minor_sections=8)
    ring.apply_translation([0, 0, depth]); finish(ring, "Engraved ring", material); emblem.add_geometry(ring)
left = [(-.04,.42),(-.30,.62),(-.84,.84),(-.63,.53),(-.82,.50),(-.36,.22),(-.20,.27),(-.12,-.05)]
right = [(-x,y) for x,y in reversed(left)]
for name, pts in [("Left swept wing",left),("Right swept wing",right)]:
    m=polygon_extrude(name,pts,.09,"gold");m.apply_translation([0,0,.13]);emblem.add_geometry(m)
for name,pts,matname in [
    ("Falcon chest",[(0,.5),(.15,.22),(.09,-.08),(0,-.38),(-.09,-.08),(-.15,.22)],"pale_gold"),
    ("Falcon crown",[(0,.33),(.20,.27),(.10,.18),(0,.21),(-.10,.18),(-.20,.27)],"gold"),
    ("Jade beak",[(.03,.28),(.16,.32),(.09,.18)],"jade")]:
    m=polygon_extrude(name,pts,.11,matname);m.apply_translation([0,0,.16]);emblem.add_geometry(m)
for deg in range(0,360,30):
    a=math.radians(deg)
    sphere(emblem,"Rim rivet",(0.92*math.cos(a),0.92*math.sin(a),.13),(.035,.035,.025),"pale_gold",1)
export(emblem,"saqoor_falcon_emblem.glb")

# Character uses Unity-style Y-up coordinates and faces toward -Z.
operator = trimesh.Scene()
# Boots, legs and kneepads
for side,label in [(-1,"L"),(1,"R")]:
    x=side*.22
    box(operator,f"Boot {label}",(.30,.22,.40),(x,.12,-.05),"dark")
    box(operator,f"Shin guard {label}",(.29,.44,.30),(x,.39,0),"armor_light")
    box(operator,f"Knee pad {label}",(.32,.16,.32),(x,.58,-.015),"dark")
    box(operator,f"Thigh armor {label}",(.33,.40,.34),(x,.83,.02),"armor")
# Torso / vest / plates
box(operator,"Lower torso",(.68,.44,.39),(0,1.13,.02),"armor")
box(operator,"Tactical vest",(.75,.54,.27),(0,1.34,-.045),"fabric")
box(operator,"Chest plate L",(.27,.30,.09),(-.18,1.42,-.19),"armor_light")
box(operator,"Chest plate R",(.27,.30,.09),(.18,1.42,-.19),"armor_light")
box(operator,"Falcon insignia",(.13,.14,.025),(0,1.36,-.245),"gold")
box(operator,"Utility belt",(.73,.1,.36),(0,1.02,-.01),"dark")
box(operator,"Backpack",(.45,.6,.28),(0,1.34,.25),"armor_light")
box(operator,"Backpack flap",(.41,.11,.28),(0,1.63,.25),"armor")
# Head and helmet
sphere(operator,"Head",(0,1.83,.01),(.18,.24,.18),"skin",2)
sphere(operator,"Ballistic helmet",(0,1.99,.01),(.25,.18,.22),"armor_light",2)
box(operator,"Helmet front rim",(.34,.05,.055),(0,1.96,-.195),"dark")
box(operator,"Helmet gold strip",(.06,.045,.22),(0,2.11,-.04),"gold")
# Arms and gloves
for side,label in [(-1,"L"),(1,"R")]:
    sphere(operator,f"Shoulder {label}",(side*.47,1.48,.02),(.21,.21,.22),"armor_light",1)
    box(operator,f"Upper arm {label}",(.21,.38,.22),(side*.49,1.27,-.015),"armor")
    box(operator,f"Forearm {label}",(.20,.24,.22),(side*.50,1.01,-.1),"armor_light")
    sphere(operator,f"Glove {label}",(side*.50,.86,-.11),(.12,.12,.13),"dark",1)
# Generic non-functional game prop rifle, stylized and intentionally simple
box(operator,"Training rifle body",(.14,.58,.14),(.30,1.12,-.43),"dark")
box(operator,"Training rifle handguard",(.17,.28,.17),(.30,1.12,-.67),"armor_light")
box(operator,"Training rifle barrel",(.05,.24,.05),(.30,1.12,-.91),"dark")
box(operator,"Training rifle stock",(.14,.20,.16),(.30,1.12,-.15),"fabric")
box(operator,"Training rifle magazine",(.08,.12,.20),(.30,.98,-.48),"dark")
box(operator,"Utility pouch L",(.14,.12,.18),(-.30,1.04,-.18),"armor_light")
box(operator,"Utility pouch R",(.14,.12,.18),(.30,1.04,-.18),"armor_light")
box(operator,"Radio antenna",(.02,.02,.22),(-.20,1.71,.22),"dark")
export(operator,"saqoor_operator.glb")

# Supply crate prop
crate = trimesh.Scene()
box(crate,"Crate base",(1.5,1.05,1.1),(0,.55,0),"crate")
box(crate,"Armoured lid",(1.58,.15,1.18),(0,1.12,0),"dark")
for x in [-.61,.61]:
    for z in [-.55,.55]:
        box(crate,"Gold corner rail",(.085,.91,.055),(x,.58,z),"gold")
for z in [-.42,.42]:
    box(crate,"Reinforced top strap",(1.34,.045,.07),(0,1.22,z),"gold")
box(crate,"Front emblem plate",(.50,.36,.035),(0,.61,-.574),"teal")
# Small gold V / falcon chevron on the front plate
m=polygon_extrude("Supply falcon mark",[(-.16,.07),(-.32,.17),(-.18,-.015),(0,-.18),(.18,-.015),(.32,.17),(.16,.07),(.06,.09),(0,.015),(-.06,.09)],.035,"gold")
m.apply_transform(trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]))
m.apply_translation([0,.61,-.598]);crate.add_geometry(m)
export(crate,"saqoor_supply_crate.glb")
